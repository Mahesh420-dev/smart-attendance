#!/usr/bin/env python
# coding: utf-8

import tkinter as tk
from tkinter import *
from tkinter import filedialog
from PIL import Image, ImageTk
import os
import show_attendance
import takeImage
import trainImage
import automaticAttendance   

# Paths
haar_path = "C:/Users/ASUS/SmartAttendance/haarcascade_frontalface_default.xml"
train_path = "TrainingImage"
model_path = "TrainingImageLabel/Trainner.yml"
attendance_path = "Attendance"
student_csv = "StudentDetails/studentdetails.csv"

# Ensure required folders exist
os.makedirs(train_path, exist_ok=True)
os.makedirs(attendance_path, exist_ok=True)
os.makedirs("StudentDetails", exist_ok=True)
os.makedirs("TrainingImageLabel", exist_ok=True) 

# Text-to-Speech
import pyttsx3
def text_to_speech(text):
    try:
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
    except Exception as e:
        print("TTS error:", e)

# Root Window
root = tk.Tk()
root.title("Facial Attendance System")
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
root.geometry(f"{screen_width}x{screen_height}")

# ---------- FIXED BACKGROUND IMAGE (ONLY THIS CHANGED) ----------
# Background Image
try:
    bg_img = Image.open("images/background.jpg")
    bg_img = bg_img.resize((screen_width, screen_height), Image.LANCZOS)
    root.bg_photo = ImageTk.PhotoImage(bg_img)

    bg_label = Label(root, image=root.bg_photo)
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)
except Exception as e:
    print("Background not found:", e)

# HEADER BAR
header = tk.Frame(root, bg="#157CE2", height=60)
header.pack(fill=X)

try:
    logo_img = Image.open("UI_Image_own/0001.png").resize((50, 50))
    root.logo_icon = ImageTk.PhotoImage(logo_img)
    logo_label = tk.Label(header, image=root.logo_icon, bg="#99C7F6")
    logo_label.place(x=20, y=5)
except:
    print("Logo image not found!")

title = tk.Label(header, text="CLASS VISION", fg="white", bg="#99C7F6",
                 font=("Segoe UI", 22, "bold"))
title.place(x=90, y=12)

# WELCOME MESSAGE
welcome = tk.Label(root,
                   text="Welcome to Face Recognition Attendance System",
                   font=("Segoe UI", 16, "bold"),
                   fg="#003366", bg="#d6f1ff", pady=15, padx=20)
welcome.pack(pady=(15, 5))

# BUTTON PANEL
button_panel = Frame(root, bg="#99C7F6")
button_panel.pack(pady=40)

# Register Student
def open_register():
    top = Toplevel()
    top.title("Register Student")
    top.geometry("500x400")
    top.configure(bg="black")

    Label(top, text="Enter Student Details", font=("Segoe UI", 14),
          fg="cyan", bg="black").pack(pady=10)
    Label(top, text="Enrollment No:", font=("Segoe UI", 12),
          fg="white", bg="black").pack()
    entry_id = Entry(top, font=("Segoe UI", 12))
    entry_id.pack()

    Label(top, text="Name:", font=("Segoe UI", 12),
          fg="white", bg="black").pack()
    entry_name = Entry(top, font=("Segoe UI", 12))
    entry_name.pack()

    status = Label(top, text="", font=("Segoe UI", 10),
                   bg="black", fg="lime")
    status.pack(pady=10)

    def capture_face():
        eid = entry_id.get().strip()
        name = entry_name.get().strip()
        if not eid or not name:
            status.config(text="Please fill all fields")
            return
        takeImage.TakeImage(eid, name, haar_path, train_path,
                            status, lambda: None, text_to_speech)
        status.config(text="Image Captured.")

    def train_model():
        trainImage.TrainImage(haar_path, train_path, model_path,
                              status, text_to_speech)
        status.config(text="Model trained!")

    Button(top, text="Capture Image", command=capture_face,
           font=("Segoe UI", 12), bg="#007acc", fg="white").pack(pady=5)
    Button(top, text="Train Images", command=train_model,
           font=("Segoe UI", 12), bg="Blue", fg="black").pack(pady=5)

# Attendance
def open_attendance():
    automaticAttendance.subjectChoose(text_to_speech)

# View Attendance
def open_viewer():
    show_attendance.subjectchoose(text_to_speech)

# Exit
def exit_app():
    root.destroy()

# Button builder
root.image_refs = {}
def build_button(image_path, label, command, col):
    try:
        img = Image.open(image_path).resize((140, 140))
        icon = ImageTk.PhotoImage(img)
        root.image_refs[image_path] = icon
        btn = Button(button_panel, image=icon, text=label, compound="top",
                     font=("Segoe UI", 12, "bold"),
                     bg="#f8f8f8", fg="#333", bd=2, relief="raised",
                     command=command, activebackground="#b3e6ff")
        btn.grid(row=0, column=col, padx=60, pady=10)
    except:
        print(f"Button image not found: {image_path}")

# BUTTONS
build_button("images/register.jpg", "Register Student", open_register, 0)
build_button("images/attendance.jpg", "Mark Attendance", open_attendance, 1)
build_button("images/verify.jpg", "View Attendance", open_viewer, 2)

Button(root, text="EXIT", command=exit_app,
       font=("Segoe UI", 12, "bold"),
       bg="red", fg="white", padx=20, pady=5).pack(pady=20)

root.mainloop()
