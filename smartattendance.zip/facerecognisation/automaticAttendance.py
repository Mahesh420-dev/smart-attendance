import cv2
import os
import pandas as pd
from datetime import datetime
import warnings
warnings.filterwarnings("ignore")
def subjectChoose(tts):
    haar_path = "haarcascade_frontalface_default.xml"
    model_path = "TrainingImageLabel/Trainner.yml"
    attendance_path = "Attendance"
    student_csv = "StudentDetails/studentdetails.csv"
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    if not os.path.exists(model_path):
        tts("No trained model found. Train images first.")
        return

    recognizer.read(model_path)
    if not os.path.exists(haar_path):
        tts("Haar Cascade file missing.")
        return
    faceCascade = cv2.CascadeClassifier(haar_path)
    if os.path.exists(student_csv):
        student_df = pd.read_csv(student_csv, encoding="ISO-8859-1", on_bad_lines='skip')
        student_df["Enrollment"] = student_df["Enrollment"].astype(int)
    else:
        tts("Student details missing.")
        return
    cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not cam.isOpened():
        cam = cv2.VideoCapture(1, cv2.CAP_DSHOW)
        if not cam.isOpened():
            tts("Camera not accessible.")
            return
    cv2.namedWindow("facial Attendance", cv2.WINDOW_NORMAL)
    font = cv2.FONT_HERSHEY_SIMPLEX
    attendance = pd.DataFrame(columns=['Enrollment', 'Name', 'Date', 'Time'])
    recognized_ids = set()

    THRESHOLD = 90  # confidence threshold
    while True:
        ret, im = cam.read()
        if not ret:
            continue

        gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)

        faces = faceCascade.detectMultiScale(
            gray, scaleFactor=1.3, minNeighbors=5, minSize=(120, 120)
        )

        for (x, y, w, h) in faces:
            face_roi = gray[y:y+h, x:x+w]
            face_roi = cv2.resize(face_roi, (200, 200))

            Id, conf = recognizer.predict(face_roi)
            print("Predicted:", Id, "Conf:", conf)
            if conf > THRESHOLD or Id not in student_df["Enrollment"].values:
                cv2.putText(im, "Unknown", (x, y - 10), font, 1, (0, 0, 255), 2)
                continue
            name = student_df.loc[student_df["Enrollment"] == Id, "Name"].values[0]
            ts = datetime.now()
            date = ts.strftime("%Y-%m-%d")
            time = ts.strftime("%H:%M:%S")

            if Id not in recognized_ids:
                attendance.loc[len(attendance)] = [Id, name, date, time]
                recognized_ids.add(Id)

            cv2.putText(im, name, (x, y - 10), font, 1, (0, 255, 0), 2)
        cv2.imshow("facial Attendance", im)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        if len(recognized_ids) > 0:
            break
    os.makedirs(attendance_path, exist_ok=True)
    ts = datetime.now()
    filename = os.path.join(attendance_path, f"Attendance_{ts.strftime('%Y-%m-%d_%H-%M-%S')}.csv")
    attendance.to_csv(filename, index=False)
    cam.release()
    cv2.destroyAllWindows()
    if len(recognized_ids) > 0:
        tts("Attendance marked successfully")
        print("Attendance marked successfully")
    else:
        tts("No valid face recognized.")
        print("No valid face recognized.")
