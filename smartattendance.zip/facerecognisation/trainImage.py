import cv2
import numpy as np
import os
from PIL import Image

def TrainImage(haar_path, train_path, model_path, status, tts):
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    detector = cv2.CascadeClassifier(haar_path)
    def getImagesAndLabels(path):
        imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
        faceSamples = []
        ids = []
        for imagePath in imagePaths:
            pilImage = Image.open(imagePath).convert('L')  # grayscale
            imageNp = np.array(pilImage, 'uint8')
            id = int(os.path.split(imagePath)[-1].split(".")[1])
            faces = detector.detectMultiScale(imageNp)
            for (x, y, w, h) in faces:
                faceSamples.append(imageNp[y:y+h, x:x+w])
                ids.append(id)
        return faceSamples, ids
    faces, ids = getImagesAndLabels(train_path)
    recognizer.train(faces, np.array(ids))
    recognizer.write(model_path)
    status.config(text="Model trained successfully")
    tts("Model trained successfully")