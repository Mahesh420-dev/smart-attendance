import cv2, os
import pandas as pd
def TakeImage(eid, name, haar_path, train_path, status, callback, tts):
    cam = cv2.VideoCapture(0)
    detector = cv2.CascadeClassifier(haar_path)
    sampleNum = 0
    while True:
        ret, img = cam.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, 1.3, 5)
        for (x,y,w,h) in faces:
            sampleNum += 1
            cv2.imwrite(os.path.join(train_path, f"{name}.{eid}.{sampleNum}.jpg"), 
                        gray[y:y+h, x:x+w])
            cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
            cv2.imshow('Capturing Faces', img)

        if cv2.waitKey(1) & 0xFF == ord('q') or sampleNum > 20:
            break
    cam.release()
    cv2.destroyAllWindows()
    csv_path = "StudentDetails/studentdetails.csv"
    os.makedirs("StudentDetails", exist_ok=True)
    if os.path.exists(csv_path):
       df = pd.read_csv(csv_path, encoding='latin1')
    else:
        df = pd.DataFrame(columns=["Enrollment", "Name"])
    if eid not in df["Enrollment"].astype(str).values:
        df.loc[len(df)] = [eid, name]
        df.to_csv(csv_path, index=False)
    status.config(text="Images saved and student registered")
    tts("Student registered successfully")
