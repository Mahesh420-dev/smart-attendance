import tkinter as tk
from tkinter import ttk
import pandas as pd
import os
def subjectchoose(text_to_speech):
    attendance_path = "Attendance"
    viewer = tk.Toplevel()
    viewer.title("Attendance Viewer")
    viewer.geometry("700x500")
    viewer.configure(bg="white")
    label = tk.Label(viewer, text="Attendance Records",
                     font=("Segoe UI", 14, "bold"), bg="white", fg="blue")
    label.pack(pady=10)
    if not os.path.exists(attendance_path) or not os.listdir(attendance_path):
        tk.Label(viewer, text="No attendance records found.",
                 font=("Segoe UI", 12), bg="white", fg="red").pack(pady=20)
        text_to_speech("No attendance records found")
        return
    all_files = [f for f in os.listdir(attendance_path) if f.endswith(".csv")]
    data_frames = []
    for file in all_files:
        full_path = os.path.join(attendance_path, file)
        df = pd.read_csv(full_path)
        df["File"] = file 
        data_frames.append(df)
    final_df = pd.concat(data_frames, ignore_index=True)
    cols = list(final_df.columns)
    tree = ttk.Treeview(viewer, columns=cols, show="headings")
    for col in cols:
        tree.heading(col, text=col)
        tree.column(col, width=150)
    for _, row in final_df.iterrows():
        tree.insert("", "end", values=list(row))
    tree.pack(expand=True, fill="both")
    text_to_speech("Attendance records displayed")
